/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.Produto;
import dao.Usuario;
import factory.ConnectionFactory;
import java.sql.Connection;
import java.util.ArrayList;
import model.ProdutoModel;

/**
 *
 * @author Hugo
 */
public class ProdutoController {

    private Usuario usuario;
    private Produto produto;

    public ProdutoController(Produto produto) {
        this.produto = produto;
    }

    public int cadastrarProduto() {
        Connection conexao = ConnectionFactory.getConnection();
        {

            ProdutoModel model = new ProdutoModel(conexao, this.produto);
            int cadastrarProd = model.cadastrarProduto();

            return cadastrarProd;
        }
    }

    public int consultarProduto() {
        Connection conexao = ConnectionFactory.getConnection();
        {

            ProdutoModel model = new ProdutoModel(conexao, this.produto);

            Produto consultarProd = model.consultaProduto();

        }
        return 0;

    }
    
     public Produto buscaPorNome() {
        Connection conexao = ConnectionFactory.getConnection();
        
        ProdutoModel model = new ProdutoModel(conexao, this.produto);
        
        Produto prod = model.buscaPorNome();
        
        return prod;

    }
     
     public ArrayList<Produto> listar() {
        Connection conexao = ConnectionFactory.getConnection();
        ProdutoModel model = new ProdutoModel(conexao, this.produto);
        ArrayList<Produto> lista = model.listar();
        return lista;
    }

    public int editar() {
        Connection conexao = ConnectionFactory.getConnection();
        {

            ProdutoModel model = new ProdutoModel(conexao, this.produto);

            int consultarProd = model.editar();
            
        }
        return 0;

    }
    
     public int deletar() {
        Connection conexao = ConnectionFactory.getConnection();
        {

            ProdutoModel model = new ProdutoModel(conexao, this.produto);

            int cadastrado = model.deletar();

        }
        return 0;

    }
}

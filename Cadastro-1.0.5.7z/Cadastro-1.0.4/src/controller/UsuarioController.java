package controller;

import dao.Produto;
import dao.Usuario;
import factory.ConnectionFactory;
import java.sql.Connection;
import java.util.ArrayList;
import model.UsuarioModel;

public class UsuarioController {

    private Usuario usuario;

    public UsuarioController(Usuario usu) {
        this.usuario = usu;
    }

    public Usuario login() {
        Connection conexao = ConnectionFactory.getConnection();
        {
            UsuarioModel model = new UsuarioModel(conexao, this.usuario);
            Usuario resposta = model.login();
            return resposta;
        }
    }

    public int cadastro() {
        Connection conexao = ConnectionFactory.getConnection();
        {
            UsuarioModel model = new UsuarioModel(conexao, this.usuario);
            int cadastrado = model.cadastro();

            return cadastrado;
        }
    }

    public int editar() {
        Connection conexao = ConnectionFactory.getConnection();
        UsuarioModel model = new UsuarioModel(conexao, this.usuario);
        int editado = model.editar();
        return editado;
    }

    public Usuario buscaPorId() {
        Connection conexao = ConnectionFactory.getConnection();
        UsuarioModel model = new UsuarioModel(conexao, this.usuario);
        Usuario usu = model.buscaPorId();
        return usu;

    }
    
    public Usuario buscaPorNome() {
        Connection conexao = ConnectionFactory.getConnection();
        UsuarioModel model = new UsuarioModel(conexao, this.usuario);
        Usuario usu = model.buscaPorNome();
        return usu;

    }
    
    public ArrayList<Usuario> listar() {
        Connection conexao = ConnectionFactory.getConnection();
        UsuarioModel model = new UsuarioModel(conexao, this.usuario);
        ArrayList<Usuario> lista = model.listar();
        return lista;
    }

    public int deletar() {
        Connection conexao = ConnectionFactory.getConnection();
        UsuarioModel model = new UsuarioModel(conexao, this.usuario);
        int usu = model.deletar();
        return usu;

    }

}

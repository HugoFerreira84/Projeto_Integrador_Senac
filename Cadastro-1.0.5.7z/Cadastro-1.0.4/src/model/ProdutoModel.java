/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import dao.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Hugo
 */
public class ProdutoModel {

    private Connection conexao;
    private Produto produto;

    public ProdutoModel(Connection con, Produto prod) {
        this.conexao = con;
        this.produto = prod;
    }

    // Método de cadastro de usuários
    public int cadastrarProduto() {
        int cadastrado = 0;
        try {
            String sql = "INSERT INTO produtos(nomeProd, tipoProd, marcaProd, precoProd, qtdProd )VALUES (?,?,?,?,?)";
            PreparedStatement stm = conexao.prepareStatement(sql);
            stm.setString(1, this.produto.getNomeProd());
            stm.setString(2, this.produto.getTipoProd());
            stm.setString(3, this.produto.getMarcaProd());
            stm.setString(4, this.produto.getPrecoProd());
            stm.setString(5, this.produto.getQtdProd());

            cadastrado = stm.executeUpdate();
        } catch (Exception e) {

            System.out.println("Erro ao cadastrar o produto!!");
            System.out.println(e.getMessage());

        }
        return cadastrado;
    }

    public Produto consultaProduto() {
        Produto prod = new Produto();
        try {
            String sql = "SELECT * FROM produtos";
            PreparedStatement stm = this.conexao.prepareStatement(sql);

            stm.setInt(1, this.produto.getId());
            stm.setString(2, this.produto.getNomeProd());
            stm.setString(3, this.produto.getTipoProd());
            stm.setString(4, this.produto.getMarcaProd());
            stm.setString(5, this.produto.getPrecoProd());
            stm.setString(6, this.produto.getPrecoProd());

            ResultSet rs = stm.executeQuery();

            while (rs.next()) {
                prod.setId(rs.getInt("id"));
                prod.setNomeProd(rs.getString("nomeProd"));
                prod.setTipoProd(rs.getString("tipoProd"));
                prod.setMarcaProd(rs.getString("marcaProd"));
                prod.setPrecoProd(rs.getString("precoPro"));
                prod.setQtdProd(rs.getString("qtdProd"));
            }

        } catch (Exception e) {

            System.out.println("Erro ao listar os produtos");

            System.out.println(e.getMessage());

        }
        return prod;
    }
    
     public Produto buscaPorNome() {
        Produto prod = new Produto();
        try {
            String sql = "SELECT * FROM produtos WHERE nomeProd LIKE ?";
            PreparedStatement stm = this.conexao.prepareStatement(sql);
            stm.setString(1, "%" + this.produto.getNomeProd()+ "%");
            ResultSet rs = stm.executeQuery();

            while (rs.next()) {

                prod.setId(rs.getInt("id"));
                prod.setNomeProd(rs.getString("nomeProd"));
                prod.setTipoProd(rs.getString("tipoProd"));
                prod.setMarcaProd(rs.getString("marcaProd"));
                prod.setPrecoProd(rs.getString("precoProd"));
                prod.setQtdProd(rs.getString("qtdProd"));
            }

        } catch (Exception e) {
            System.out.println("Erro ao listar usuarios");
            System.out.println(e.getMessage());
        }

        return prod;
    }
     
     public ArrayList<Produto> listar() {

        ArrayList<Produto> lista = new ArrayList<Produto>();

        try {
            String sql = "SELECT id, nomeProd, tipoProd, marcaProd, precoProd, qtdProd FROM produtos";
            PreparedStatement stm = this.conexao.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Produto prod = new Produto();

                prod.setId(rs.getInt("id"));
                prod.setNomeProd(rs.getString("nomeProd"));
                prod.setTipoProd(rs.getString("tipoProd"));
                prod.setMarcaProd(rs.getString("marcaProd"));
                prod.setPrecoProd(rs.getString("precoProd"));
                prod.setQtdProd(rs.getString("qtdProd"));

                lista.add(prod);
            }
            return lista;
        } catch (Exception e) {
            System.out.println("Erro ao listar usuários");
            System.out.println(e.getMessage());
        }
        return lista;
    }

    public int editar() {
        int result = 0;

        try {
            String sql = "UPDATE produtos SET nomeProd = ?, tipoProd = ?, marcaProd = ?, precoProd = ?, qtdProd = ? WHERE id = ?";
            PreparedStatement stm = conexao.prepareStatement(sql);

            stm.setInt(1, this.produto.getId());
            stm.setString(2, this.produto.getNomeProd());
            stm.setString(3, this.produto.getTipoProd());
            stm.setString(4, this.produto.getMarcaProd());
            stm.setString(5, this.produto.getPrecoProd());
            stm.setString(6, this.produto.getQtdProd());

            result = stm.executeUpdate();
        } catch (Exception e) {
            System.out.println("Erro ao editar o produto");
            System.out.println(e.getMessage());
        }
        return result;
    }

    public int deletar() {
        int resultado = 0;
        try {
            String sql = "DELETE FROM produtos WHERE id = ?";
            PreparedStatement stm = this.conexao.prepareStatement(sql);
            stm.setInt(1, this.produto.getId());
            resultado = stm.executeUpdate();

        } catch (Exception e) {
            System.out.println("Erro ao Deletar");
            System.out.println(e.getMessage());
        }
        return resultado;
    }
}

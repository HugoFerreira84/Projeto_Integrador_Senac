package model;

import dao.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UsuarioModel {

    private Connection conexao;
    private Usuario usuario;

    public UsuarioModel(Connection con, Usuario usu) {
        this.conexao = con;
        this.usuario = usu;
    }

    public Usuario login() {
        Usuario usu = new Usuario();
        try {
            String sql = "SELECT * FROM usuario WHERE userName = ? AND senha = ?";
            PreparedStatement stm = this.conexao.prepareStatement(sql);
            stm.setString(1, this.usuario.getUserName());
            stm.setString(2, this.usuario.getSenha());
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                usu.setId(rs.getInt("id"));
                usu.setUserName(rs.getString("UserName"));
                usu.setSenha(rs.getString("senha"));
            }
        } catch (Exception e) {
            System.out.println("Erro ao fazer o login");
            System.out.println(e.getMessage());
        }
        return usu;
    }

    // Método de cadastro de usuários
    public int cadastro() {
        int cadastrado = 0;
        try {
            String sql = "INSERT INTO usuario(userName, login, cpf, dataNasc, telefone, email, endereco, cep, cidade, complemento, uf, senha)VALUES (?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement stm = conexao.prepareStatement(sql);
            stm.setString(1, this.usuario.getUserName());
            stm.setString(2, this.usuario.getLogin());
            stm.setString(3, this.usuario.getCpf());
            stm.setString(4, this.usuario.getDataNasc());
            stm.setString(5, this.usuario.getTelefone());
            stm.setString(6, this.usuario.getEmail());
            stm.setString(7, this.usuario.getEndereco());
            stm.setString(8, this.usuario.getCep());
            stm.setString(9, this.usuario.getCidade());
            stm.setString(10, this.usuario.getComplemento());
            stm.setString(11, this.usuario.getUf());
            stm.setString(12, this.usuario.getSenha());
            cadastrado = stm.executeUpdate();
        } catch (Exception  e) {
            System.out.println("Erro ao cadastrar usuário");
            System.out.println(e.getMessage());
        }
        return cadastrado;
    }

    public ArrayList<Usuario> listar() {

        ArrayList<Usuario> lista = new ArrayList<Usuario>();

        try {
            String sql = "SELECT id, UserName, cpf, dataNasc, telefone, email, endereco, cep, cidade, complemento, uf FROM usuario";
            PreparedStatement stm = this.conexao.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            while (rs.next()) {
                Usuario usu = new Usuario();

                usu.setId(rs.getInt("id"));
                usu.setUserName(rs.getString("userName"));
                usu.setCpf(rs.getString("cpf"));
                usu.setDataNasc(rs.getString("dataNasc"));
                usu.setTelefone(rs.getString("telefone"));
                usu.setEmail(rs.getString("email"));
                usu.setEndereco(rs.getString("endereco"));
                usu.setCep(rs.getString("cep"));
                usu.setCidade(rs.getString("cidade"));
                usu.setComplemento(rs.getString("complemento"));
                usu.setUf(rs.getString("uf"));

                lista.add(usu);
            }
            return lista;
        } catch (Exception e) {
            System.out.println("Erro ao listar usuários");
            System.out.println(e.getMessage());
        }
        return lista;
    }

    public Usuario buscaPorId() {
        Usuario usu = new Usuario();
        try {
            String sql = "SELECT * FROM usuario WHERE id = ?";
            PreparedStatement stm = this.conexao.prepareStatement(sql);
            stm.setInt(1, this.usuario.getId());
            ResultSet rs = stm.executeQuery();

            while (rs.next()) {

                usu.setId(rs.getInt("id"));
                usu.setUserName(rs.getString("userName"));
                usu.setCpf(rs.getString("cpf"));
                usu.setDataNasc(rs.getString("dataNasc"));
                usu.setTelefone(rs.getString("telefone"));
                usu.setEmail(rs.getString("email"));
                usu.setEndereco(rs.getString("endereco"));
                usu.setCep(rs.getString("cep"));
                usu.setCidade(rs.getString("cidade"));
                usu.setComplemento(rs.getString("complemento"));
                usu.setUf(rs.getString("uf"));

            }

        } catch (Exception e) {
            System.out.println("Erro ao listar usuarios");
            System.out.println(e.getMessage());
        }

        return usu;
    }

    public Usuario buscaPorNome() {
        Usuario usu = new Usuario();
        try {
            String sql = "SELECT * FROM usuario WHERE userName LIKE ?";
            PreparedStatement stm = this.conexao.prepareStatement(sql);
            stm.setString(1, "%" + this.usuario.getUserName() + "%");
            ResultSet rs = stm.executeQuery();
          
            while (rs.next()) {

                usu.setId(rs.getInt("id"));
                usu.setUserName(rs.getString("userName"));
                usu.setCpf(rs.getString("cpf"));
                usu.setDataNasc(rs.getString("dataNasc"));
                usu.setTelefone(rs.getString("telefone"));
                usu.setEmail(rs.getString("email"));
                usu.setEndereco(rs.getString("endereco"));
                usu.setCep(rs.getString("cep"));
                usu.setCidade(rs.getString("cidade"));
                usu.setComplemento(rs.getString("complemento"));
                usu.setUf(rs.getString("uf"));

            }

        } catch (Exception e) {
            System.out.println("Erro ao listar usuarios");
            System.out.println(e.getMessage());
        }

        return usu;
    }

    public int editar() {
        int result = 0;

        try {
            String sql = "UPDATE usuario SET userName = ?, login = ?, cpf = ?, dataNasc = ?, telefone = ?, email = ?, endereco = ?, cep = ?, cidade = ?, complemento = ?, uf = ?, senha = ? WHERE id = ?";
            PreparedStatement stm = conexao.prepareStatement(sql);
            
            stm.setString(1, this.usuario.getUserName());
            stm.setString(2, this.usuario.getLogin());
            stm.setString(3, this.usuario.getCpf());
            stm.setString(4, this.usuario.getDataNasc());
            stm.setString(5, this.usuario.getTelefone());
            stm.setString(6, this.usuario.getEmail());
            stm.setString(7, this.usuario.getEndereco());
            stm.setString(8, this.usuario.getCep());
            stm.setString(9, this.usuario.getCidade());
            stm.setString(10, this.usuario.getComplemento());
            stm.setString(11, this.usuario.getUf());
            stm.setString(12, this.usuario.getSenha());
            stm.setInt(   13, this.usuario.getId());
         
            result = stm.executeUpdate();
            
        } catch (SQLException e) {
            System.out.println("Erro ao editar usuário");
            System.out.println(e.getMessage());
        }
        return result;
    }

    public int deletar() {
        int resultado = 0;
        try {
            String sql = "DELETE FROM usuario WHERE id = ?";
            PreparedStatement stm = this.conexao.prepareStatement(sql);
            stm.setInt(1, this.usuario.getId());
            resultado = stm.executeUpdate();

        } catch (Exception e) {
            System.out.println("Erro ao Deletar");
            System.out.println(e.getMessage());
        }
        return resultado;
    }

}

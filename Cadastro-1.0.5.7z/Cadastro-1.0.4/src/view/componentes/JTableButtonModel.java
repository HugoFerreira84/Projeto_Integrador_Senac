package view.componentes;



import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;

public class JTableButtonModel extends AbstractTableModel {

    private String[] columns;
    private Object[][] rows;;

    public JTableButtonModel(String[] columns, Object[][] rows) {
        this.columns = columns;
        this.rows = rows;
    }

    public String getColumnName(int column) {
        return this.columns[column];
    }
    public int getRowCount() {
        return this.rows.length;
    }

    public int getColumnCount() {
        return this.columns.length;
    }
    public Object getValueAt(int row, int column) {
        return this.rows[row][column];
    }
    public boolean isCellEditable(int row, int column) {
        return false;
    }
    public Class getColumnClass(int column) {
        return getValueAt(0, column).getClass();
    }
}
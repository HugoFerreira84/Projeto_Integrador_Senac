/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Hugo
 */
public class Produto {

    private int id;
    private String nomeProd;
    private String tipoProd;
    private String marcaProd;
    private String precoProd;
    private String qtdProd;
    
    public Produto(){}
    
    public Produto(int id, String nomeProd, String tipoProd, String marcaProd, String precoProd, String qtdProd){
        this.id = id;
        this.nomeProd = nomeProd;
        this.tipoProd = tipoProd;
        this.marcaProd = marcaProd;
        this.precoProd = precoProd;
        this.qtdProd = qtdProd;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomeProd() {
        return nomeProd;
    }

    public void setNomeProd(String nomeProd) {
        this.nomeProd = nomeProd;
    }

    public String getTipoProd() {
        return tipoProd;
    }

    public void setTipoProd(String tipoProd) {
        this.tipoProd = tipoProd;
    }

    public String getMarcaProd() {
        return marcaProd;
    }

    public void setMarcaProd(String marcaProd) {
        this.marcaProd = marcaProd;
    }

    public String getPrecoProd() {
        return precoProd;
    }

    public void setPrecoProd(String precoProd) {
        this.precoProd = precoProd;
    }

    public String getQtdProd() {
        return qtdProd;
    }

    public void setQtdProd(String qtdProd) {
        this.qtdProd = qtdProd;
    }
   
    
}

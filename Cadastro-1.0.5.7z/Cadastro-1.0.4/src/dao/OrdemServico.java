/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Hugo
 */
public class OrdemServico {
    private String nomeCli;
    private String tiposervico;
    private String veiculo;
    private String tabela;
    
    public OrdemServico(){}
    
    public OrdemServico(String nomeCli, String tipoServico, String veiculo, String tabela){
        this.nomeCli = nomeCli;
        this.tiposervico = tipoServico;
        this.veiculo = veiculo;
        this.tabela = tabela;
    }

    public String getNomeCli() {
        return nomeCli;
    }

    public void setNomeCli(String nomeCli) {
        this.nomeCli = nomeCli;
    }

    public String getTiposervico() {
        return tiposervico;
    }

    public void setTiposervico(String tiposervico) {
        this.tiposervico = tiposervico;
    }

    public String getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(String veiculo) {
        this.veiculo = veiculo;
    }

    public String getTabela() {
        return tabela;
    }

    public void setTabela(String tabela) {
        this.tabela = tabela;
    }
    
    
}

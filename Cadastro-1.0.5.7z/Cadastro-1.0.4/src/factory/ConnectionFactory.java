
package factory;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {

    public static boolean status;
    public static Connection getConnection(){
        Connection conexao = null;
        try {
            conexao = DriverManager.getConnection("jdbc:mysql://localhost:3308/cadastro","root","");
        } catch (Exception e) {
            System.out.println("Erro ao conectar com o banco de dados.");
            System.out.println(e.getMessage());
        }
        return conexao;
    }
}

package componentes;

import javax.swing.table.AbstractTableModel;

public class JTableButtonModel extends AbstractTableModel {

    private String[] columns;
    private Object[][] rows;;

    public JTableButtonModel(String[] columns, Object[][] rows) {
        this.columns = columns;
        this.rows = rows;
    }

    @Override
    public String getColumnName(int column) {
        return this.columns[column];
    }
    @Override
    public int getRowCount() {
        return this.rows.length;
    }

    @Override
    public int getColumnCount() {
        return this.columns.length;
    }
    @Override
    public Object getValueAt(int row, int column) {
        return this.rows[row][column];
    }
    @Override
    public boolean isCellEditable(int row, int column) {
        return false;
    }
    @Override
    public Class getColumnClass(int column) {
        return getValueAt(0, column).getClass();
    }
}